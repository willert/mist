#!/bin/sh
echo "1..1"
echo "ok 1 - source.sh"
