use strict;
use warnings;
package Acme::Dzil;
# ABSTRACT: turns baubles into trinkets
1;
__END__

=head1 NAME

Acme::Dzil

=head1 DESCRIPTION

Acme::Foo is ...

=head1 LICENSE

Copyright (C) tokuhirom

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 AUTHOR

tokuhirom E<lt>tokuhirom@gmail.comE<gt>

