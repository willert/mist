use strict;
use warnings;

use Test::More;
use Test::NoWarnings 1.04 ':early';

pass('yay!');
done_testing;

