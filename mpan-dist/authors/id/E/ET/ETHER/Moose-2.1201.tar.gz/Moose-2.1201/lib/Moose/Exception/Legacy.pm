package Moose::Exception::Legacy;
BEGIN {
  $Moose::Exception::Legacy::AUTHORITY = 'cpan:STEVAN';
}
{
  $Moose::Exception::Legacy::VERSION = '2.1201';
}

use Moose;
extends 'Moose::Exception';

1;
