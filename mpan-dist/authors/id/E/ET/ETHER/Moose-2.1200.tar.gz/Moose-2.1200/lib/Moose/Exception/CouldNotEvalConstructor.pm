package Moose::Exception::CouldNotEvalConstructor;
BEGIN {
  $Moose::Exception::CouldNotEvalConstructor::AUTHORITY = 'cpan:STEVAN';
}
{
  $Moose::Exception::CouldNotEvalConstructor::VERSION = '2.1200';
}

use Moose;
extends 'Moose::Exception';

has 'constructor_method' => (
    is       => 'ro',
    isa      => 'Class::MOP::Method::Constructor',
    required => 1
);

has 'source' => (
    is       => 'ro',
    isa      => 'Str',
    required => 1
);

has 'error' => (
    is       => 'ro',
    isa      => 'Str',
    required => 1
);

sub _build_message {
    my $self = shift;
    my $error = $self->error;
    my $source = $self->source;

    return "Could not eval the constructor :\n\n$source\n\nbecause :\n\n$error";
}

1;
