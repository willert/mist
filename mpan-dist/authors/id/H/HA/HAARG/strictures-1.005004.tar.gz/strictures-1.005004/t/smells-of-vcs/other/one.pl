use strictures 1;

new Foo 1, 2, 3;
