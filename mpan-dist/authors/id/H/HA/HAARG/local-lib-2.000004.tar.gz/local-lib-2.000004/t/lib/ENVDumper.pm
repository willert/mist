package ENVDumper;
use Data::Dumper;
print Dumper(\%ENV);
