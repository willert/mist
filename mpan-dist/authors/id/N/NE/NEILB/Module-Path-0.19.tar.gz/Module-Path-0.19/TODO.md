* Add tests for different permutations of -x, -d, -r on directories in @INC
* Add tests for all the different permutations with symlinks
* Full test coverage with Devel::Cover
