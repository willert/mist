##
# name:      Foo
# abstract:  Foo to the Bar
# author:    Ingy döt Net <ingy@ingy.net>
# license:   perl
# copyright: 2011

use v5.8.3;
package Foo::Bar;

our $VERSION = '1.23';

1;
