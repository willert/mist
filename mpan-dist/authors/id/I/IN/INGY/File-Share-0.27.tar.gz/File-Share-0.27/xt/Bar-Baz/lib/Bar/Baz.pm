##
# name:      Bar
# abstract:  Bar to the Foo
# author:    Ingy döt Net <ingy@ingy.net>
# license:   perl
# copyright: 2011

use v5.8.3;
package Bar::Baz;

our $VERSION = '1.23';

1;
