use v5.8.3;
package MB;

our $VERSION = '1.23';

1;
