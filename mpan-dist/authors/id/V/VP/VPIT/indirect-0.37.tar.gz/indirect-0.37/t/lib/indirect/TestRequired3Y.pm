package indirect::TestRequired3Y;

sub new { push @main::new, __PACKAGE__ }

new indirect::TestRequired3Y;
