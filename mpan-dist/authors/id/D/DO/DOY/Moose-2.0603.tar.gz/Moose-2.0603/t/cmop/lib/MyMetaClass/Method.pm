
package MyMetaClass::Method;

use strict;
use warnings;

use base 'Class::MOP::Method';

1;
