package Minilla::Profile::Default;
use strict;
use warnings;
use utf8;
use parent qw(Minilla::Profile::ModuleBuild);

# The default profile is Module::Build.

1;
__DATA__
