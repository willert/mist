package Local::Class1;
use Local::Mite;
with 'Local::Role2';

1;
