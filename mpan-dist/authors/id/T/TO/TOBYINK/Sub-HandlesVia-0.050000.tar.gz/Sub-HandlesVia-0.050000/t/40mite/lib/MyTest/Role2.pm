package MyTest::Role2;

use MyTest::Mite -role;
with 'MyTest::Role1';

1;
