package MyTest::Class1;

use MyTest::Mite;
with 'MyTest::Role2';

1;
