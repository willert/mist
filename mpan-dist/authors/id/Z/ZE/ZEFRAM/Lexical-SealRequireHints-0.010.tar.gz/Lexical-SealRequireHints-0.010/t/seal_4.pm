package t::seal_4;

use warnings;
use strict;

die "seal_4 death\n";

1;
