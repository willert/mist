package t::seal_3;

use warnings;
use strict;

BEGIN { die "seal_3 death\n"; }

1;
