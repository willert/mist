package Test::MyCmdAbbrev::Command::foo;

use strict;
use warnings;

use parent qw{ App::Cmd::Command };

1;
