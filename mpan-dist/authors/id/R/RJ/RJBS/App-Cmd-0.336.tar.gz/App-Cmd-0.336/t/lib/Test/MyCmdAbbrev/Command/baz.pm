package Test::MyCmdAbbrev::Command::baz;

use strict;
use warnings;

use parent qw{ App::Cmd::Command };

1;
