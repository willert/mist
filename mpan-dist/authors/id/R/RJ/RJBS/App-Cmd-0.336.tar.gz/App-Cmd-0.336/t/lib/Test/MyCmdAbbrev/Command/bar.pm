package Test::MyCmdAbbrev::Command::bar;

use strict;
use warnings;

use parent qw{ App::Cmd::Command };

1;
