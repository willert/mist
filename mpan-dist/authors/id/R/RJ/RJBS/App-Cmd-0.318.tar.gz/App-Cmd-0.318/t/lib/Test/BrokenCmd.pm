use strict;
use warnings;

package Test::BrokenCmd;
use App::Cmd::Setup -app;

1;
