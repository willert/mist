#!perl

use strict;
use warnings;

use less 'documentation';

=head1

We're going to see some serious stuff.

It will be awesome.

=cut

# ...and now we're done!

