use strict;
use warnings;
package Grandchild;
use base 'Child';

1;
__DATA__
__[a]__
111
__[d]__
