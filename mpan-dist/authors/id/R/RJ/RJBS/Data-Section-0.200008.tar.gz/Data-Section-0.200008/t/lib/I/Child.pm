use strict;
use warnings;
package I::Child;
use Godfather;
use base qw(I::Mother Godfather);
1;
__DATA__
__[b]__
22
__[c]__
33
__[d]__
44
