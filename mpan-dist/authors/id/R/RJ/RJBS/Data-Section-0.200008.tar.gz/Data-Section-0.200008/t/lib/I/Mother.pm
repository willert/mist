use strict;
use warnings;
package I::Mother;
use Data::Section -setup;

1;
__DATA__
__[a]__
1
__[b]__
2
__[c]__
3
