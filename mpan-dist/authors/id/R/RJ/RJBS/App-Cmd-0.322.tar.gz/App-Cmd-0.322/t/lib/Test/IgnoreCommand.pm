use strict;
use warnings;

package Test::IgnoreCommand;
use App::Cmd::Setup -app;

1;
