use strict;
use warnings;
package I::Grandchild;
use base 'I::Child';

1;
__DATA__
__[a]__
111
__[d]__
