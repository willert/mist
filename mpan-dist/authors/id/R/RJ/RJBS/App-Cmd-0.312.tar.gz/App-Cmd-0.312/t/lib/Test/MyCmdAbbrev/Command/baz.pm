package Test::MyCmdAbbrev::Command::baz;

use strict;
use warnings;

use base qw{ App::Cmd::Command };

1;
