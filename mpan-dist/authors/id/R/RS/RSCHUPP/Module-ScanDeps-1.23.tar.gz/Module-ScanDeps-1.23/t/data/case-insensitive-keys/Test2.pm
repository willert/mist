package Test2;
use Cwd;
$foo->cwd->foo();
1;
