package TestC;

use TestD;

1;
__END__