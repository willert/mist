# the package in implemented intentionally in Text::MicroTemplate
use Text::MicroTemplate;
1;
