package Test::MyAny::Moose;
use Moose;

extends qw(MooseX::App::Cmd);

1;
