package Test::ConfigFromFile;
use Any::Moose;

extends qw(MooseX::App::Cmd);

1;
