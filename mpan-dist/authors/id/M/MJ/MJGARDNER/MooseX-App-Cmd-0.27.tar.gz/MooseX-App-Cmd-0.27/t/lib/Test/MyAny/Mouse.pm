package Test::MyAny::Mouse;
use Mouse;

extends qw(MouseX::App::Cmd);

1;
